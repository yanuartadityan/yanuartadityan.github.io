---
title: Sort of&#8230;A Self Introduction
excerpt: "This is just a simple introduction. In Deutsch style. Frag Mir!"
category: blog
layout: post
comments: true
tags: [introduction, language]
---
* * *
I have learned basic German at Göethe-Institut, Bandung back in 2013 for about 3 months. It was bloody 3 months. I have to say, I&#8217;m suck at grasping the idea of grammar, vocabulary and everythings. I was pretty much sure how the words should be typed on. But, most of the time, I really want to cut my right pinky because it became physically intimate with BACKSPACE button. Darn it. The symphony between fingers and brain is just not there, never. That is why I called this syndrome,

> &#8216;brain-and-finger-contradictive-neosis&#8217;

<!--more-->

When you are typing on a competitive scene, reaching 100 words per minute will take you onto top 2% of rank. You need to average ~98% accuracy and consistently as well to stay at that minimum rate. On Indonesian and English, it is not much of a problem. But, when typing on German words, well, my mind shattered, my fingers fatigued and my brain was not working properly. Hour by hour I learned to adapt into super-awkward German QWERTZ layout (normal keyboard is QWERTY, just in case you don&#8217;t know) without success. The WPM always stay below ~60 and it freaks me out. Yeah&#8230; Whatever&#8230;

<img class="alignnone  wp-image-61 aligncenter" src="http://i1.wp.com/www.januaditya.com/wp-content/uploads/2014/04/german.png?resize=147%2C195" alt="german" data-recalc-dims="1" />

And hey, this is the first few paragraphs of my self introduction or **Selbst Vorstellung**. Written on proper Deutsch,

> Hi!
> 
> Wie gehts? Ich bin super! Mein Name ist Janu und Ich bin 25 Jahre alt. Ich komme aus Madiun und wohne jetzt in Dago Bengkok.
> 
> Nach Bandung habe ich für meine Studium gekommen. An der ITB habe ich Elektrotechnik studiert. Und jetzt arbeite ich als Forscher bei PAU-ITB. Mein Büro in zweiten bis vierten Etage von PAU-ITB. Am Montag bis Doonerstag fahre ich fünfzehn Minuten mit dem Motorrad. Und am Freitag, fahre ich mein Fahrrad zum Arbeit. Am Wochenende gehe ich mit meinem Freund von mir zum Park zusammen mit dem Fahhrad aus.
> 
> Ich berate unsere Projekten für die Indonesia Regierung. Wir programmieren vierten Generation LTE mit dem C Programmiersprache. Unsere Projekte ist groß und schwer. Es gibt 15 Ingenieure arbeiten daran.
> 
> In Deutschland möchte ich studieren. Das ist warum ich im GI Sprachkurs machen. Ich finde der Kurs ist gut.
> 
> Ja das ist alles. Vielen dank.

That is all mate! Cheers <img src="http://i0.wp.com/www.januaditya.com/wp-includes/images/smilies/icon_smile.gif?w=940" alt=":)" class="wp-smiley" data-recalc-dims="1" />