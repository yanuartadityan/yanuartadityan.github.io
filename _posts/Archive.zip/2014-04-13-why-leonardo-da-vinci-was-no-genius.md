---
title: Long Game Part II - Leonardo da Vinci
excerpt: "Second Part of the Long Game series. Watch and learn how public perception is often misleading."
category: blog
layout: post
comments: true
tags: [long game, vimeo, mumbling]
---
* * *
Interesting video essay which tells us that public perception is often misleading. Find yourself where you are standing now and realize that no one is impeccable.

<iframe src="//player.vimeo.com/video/84022735?title=0&amp;byline=0&amp;portrait=0" width="500" height="281" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>

>Da Vinci's appearance in *Assassin's Creed* was quite inaccurate then? No?