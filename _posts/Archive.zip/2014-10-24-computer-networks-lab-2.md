---
title: 'My First &#8216;Markdown&#8217; Lab Report'
excerpt: "Semi confidential stuff from my lab here. Don't worry, I'm kidding. I just tried how to use Markdown more as a day-to-day tools. And this is the first lab report which was made using Markdown from Google Drive's Stack Edit. You can generate PDF version an *voila*."
category: blog
layout: post
comments: true
tags: [markdown, tech, study, chalmers]
---
* * *

<section id="table-of-contents" class="toc">
  <header>
    <h3>Simple Echo Server</h3>
  </header>
<div id="drawer" markdown="1">
*  Auto generated table of contents
{:toc}
</div>
</section><!-- /#table-of-contents -->

**Computer Networks &#8211; Lab2A**  
Sept 15, 2014
<br />
by  
**LAB GROUP 30**  
NUGRAHA, *Yanuar Tri Aditya*  
SEKAR, *Sushil*

* * *

##Exercise I.a.1
The listening socket is bound to a specific address. What address is this? (Give both the symbolic name used in the code, and the corresponding IPv4 address in numeric or dotted notation).

> The address’ symbol is INADDR_ANY.
> 
> The IP for this is 0.0.0.0. With this address, server will bound its socket to all available interfaces.

##Exercise I.a.2  
In the code there is a call to recv() as follows: ret=recv(cd.sock, cd.buffer, KTransferBufferSize, 0); The return value ret will be one of the following:

> 1.  ret = -1
> 2.  ret = 0
> 3.  0 < ret < KTransferBufferSize
> 4.  ret=KTransferBufferSize

Describe the implications of each case! Additionally, why is cd.buffer (see ConnectionData declaration) defined to be of size kTransferBufferSize+1 rather than just plain kTransferBufferSize?

> 1.  If the return value ‘ret’ is -1, it means there is an error on the recv() function. In order to determine kind of error, we can use strerror() using global var errno.
> 2.  If the return value ‘ret’ is 0, it states that the peer has closed its half side of the connection.
> 3.  When 0 < ret < KTransferBufferSize, it means that recv() function succeed on capturing incoming packets with each packet has ‘ret’ length.
> 4.  kTransferBufferSize is the maxim buffer for each recv() routine. Therefore, if the ‘ret’ value is equal to kTransferBufferSize, the maximum buffer is reached and recv() need to be invoked again until the whole packetcd.buffer is defined to be the size of kTransferBufferSize+1 so as to accommodate the end of character value “\0”. This extra char or space indicate the EOF of the packet.

##Exercise I.a.3
Sending is performed using the send() method as follows: ret = send( cd.sock,cd.buffer+cd.bufferOffset, cd.bufferSize-cd.bufferOffset, MSG\_NOSIGNAL ); How does the send() method indicate that the connection in question has been closed/reset? How does MSG\_NOSIGNAL relate to this (on linux machines)?

> If the connection is closed/reset, send() will return ret value to -1 with errno set to [ECONNRESET] or [EPIPE]. In order to read this errno value in human-readable way, we can use strerror().
> 
> With passing MSG_NOSIGNAL to send(), it will force the transmission to transmit the remaining packet after its connection closed.

##Exercise I.c.1
Try to send messages with each of the clients. Describe the results – do you receive a response immediately?.  
Check with netstat and document the status of the connection from each client.

> No, we didn’t get the immediate response from the server. On the netstat, both clients status are shown as CONNECTION_ESTABLISHED, however the first client was in communication with the server and hence the second client had to wait for a response from the server.

    tcp4       4      0  localhost.5703         localhost.58037        ESTABLISHED
    tcp4       0      0  localhost.58037        localhost.5703         ESTABLISHED
    tcp4       0      0  localhost.5703         localhost.58036        ESTABLISHED
    tcp4       0      0  localhost.58036        localhost.5703         ESTABLISHED
    

##Exercise I.c.2  
When you disconnected the first client, what happened? Explain why.

> The second client will receive its packets immediately, not in waiting state anymore. The second client is in waiting loop in this part of the code:

        while( received < expected )
        {
            ssize_t ret = recv( connfd,
                recvBuffer + received,
                expected-received,
                0
            );
    
            printf("the value of recv retval is %d\n", (int)ret);
    
            if( 0 == ret )
            {
                fprintf( stderr, "Error - connection closed unexpectedly!\n" );
                return 1;
            }
            if( -1 == ret )
            {
                perror( "recv() failed" );
                return 1;
            }
    
            received += ret;
        }
    
    The client is waiting for recv() function to return the result, but because there is a blocking from first client which is already connected to the server. 
    

##Exercise I.c.3
Measure the round trip time when the client and server are running on the same machine. Also measure the round trip time when they are on different machines.  
Can you observe any differences? Write down the times. (Note: take the average of a few (> 5) attempts.)

**SAME MACHINE**

    Yanuars-MacBook-Pro:Lab2 januaditya$ ./client-simple 0.0.0.0 5703 Input> hello
    Sending string `hello' (5 bytes)
    Response = `hello'
    - response does match original query
    - round trip time is 0.115527 ms 
    Input> hello
    Sending string `hello' (5 bytes) 
    Response = `hello'
    - response does match original query
    - round trip time is 0.086564 ms 
    Input> hello
    Response = `hello'
    - response does match original query
    - round trip time is 0.078919 ms 
    Input> hello
    Sending string `hello' (5 bytes) 
    Response = `hello'
    ￼- response does match original query
    - round trip time is 0.098123 ms 
    Input> hello
    Sending string `hello' (5 bytes) 
    Response = `hello'
    - response does match original query
    - round trip time is 0.096834 ms 
    Input> hello
    Sending string `hello' (5 bytes) 
    Response = `hello'
    - response does match original query
    - round trip time is 0.082066 ms
    

**DIFFERENT MACHINE**

    [yanuar@remote2 Lab2]$ ./client-simple remote1.student.chalmers.se 5703
    Input> hello
    Sending string `hello' (5 bytes)
    Response = `hello'
      - response does match original query
      - round trip time is 0.321469 ms
    Input> hello
    Sending string `hello' (5 bytes)
    Response = `hello'
      - response does match original query
      - round trip time is 0.304778 ms
    Input> hello
    Sending string `hello' (5 bytes)
    Response = `hello'
      - response does match original query
      - round trip time is 0.308340 ms
    Input> hello
    Sending string `hello' (5 bytes)
    Response = `hello'
      - response does match original query
      - round trip time is 0.347240 ms
    Input> hello
    Sending string `hello' (5 bytes)
    Response = `hello'
      - response does match original query
      - round trip time is 0.305198 ms
    

> literally, there is a significant delay of 0.2-0.3ms between same machine and different machine.

##￼Exercise I.d.1
Run the above command (make sure that the server is still running), and note the results.

**here is the captured result:**

    Simulating 7 clients.
    Establishing 7 connections... 
      successfully initiated 7 connection attempts!
    Connect timing results for 7 successful connections
      - min time: 0.099915 ms
      - max time: 0.291581 ms
      - average time: 0.159059 ms
     (0 connections failed!)
    Roundtrip timing results for 7 connections for 255 round trips
      - min time: 5.969844 ms
      - max time: 41.653968 ms
      - average time: 24.648037 ms
    
    Simulating 10 clients.
    Establishing 10 connections... 
      successfully initiated 10 connection attempts!
    Connect timing results for 10 successful connections
      - min time: 0.181476 ms
      - max time: 0.331597 ms
      - average time: 0.223703 ms
     (0 connections failed!)
    Roundtrip timing results for 9 connections for 255 round trips
      - min time: 7.569982 ms
      - max time: 56.472186 ms
      - average time: 32.692733 ms
    
    Simulating 15 clients.
    Establishing 15 connections... 
      successfully initiated 15 connection attempts!
    Connect timing results for 15 successful connections
      - min time: 0.180090 ms
      - max time: 0.468983 ms
      - average time: 0.287662 ms
     (0 connections failed!)
    Roundtrip timing results for 9 connections for 255 round trips
      - min time: 6.695092 ms
      - max time: 57.091298 ms
      - average time: 31.806458 ms
    
    Simulating 30 clients.
    Establishing 30 connections... 
      successfully initiated 30 connection attempts!
    Connect timing results for 16 successful connections
      - min time: 0.184986 ms
      - max time: 100.978011 ms
      - average time: 44.404177 ms
     (14 connections failed!)
    Roundtrip timing results for 16 connections for 255 round trips
      - min time: 7.026619 ms
      - max time: 60.513460 ms
      - average time: 30.696535 ms
    
    Simulating 50 clients.
    Establishing 50 connections... 
      successfully initiated 50 connection attempts!
    Connect timing results for 20 successful connections
      - min time: 0.219944 ms
      - max time: 292.559716 ms
      - average time: 110.595778 ms
     (30 connections failed!)
    Roundtrip timing results for 18 connections for 255 round trips
      - min time: 7.538633 ms
      - max time: 63.008804 ms
      - average time: 32.185063 ms
    
    Simulating 100 clients.
    Establishing 100 connections... 
      successfully initiated 100 connection attempts!
    Connect timing results for 77 successful connections
      - min time: 1.406008 ms
      - max time: 283.681774 ms
      - average time: 170.667043 ms
     (23 connections failed!)
    Roundtrip timing results for 24 connections for 255 round trips
      - min time: 7.009906 ms
      - max time: 103.263967 ms
      - average time: 40.445860 ms
    

> we tested 7, 10, 15, 30, 50 and 100 clients.

<img class="aligncenter" src="https://imagizer.imageshack.us/v2/928x838q90/r/673/qvTEAv.png" alt="enter image description here" width="943" height="852" />

##Exercise I.d.2
Take note of the timing results. You will want to compare them to results in the next Lab/Exercise.  
(You don’t have to hand in the results, though.)

    Simulating 7 clients.
    Establishing 7 connections... 
      successfully initiated 7 connection attempts!
    Connect timing results for 7 successful connections
      - min time: 0.099915 ms
      - max time: 0.291581 ms
      - average time: 0.159059 ms
     (0 connections failed!)
    Roundtrip timing results for 7 connections for 255 round trips
      - min time: 5.969844 ms
      - max time: 41.653968 ms
      - average time: 24.648037 ms
    
    Simulating 7 clients.
    Establishing 7 connections... 
      successfully initiated 7 connection attempts!
    Connect timing results for 7 successful connections
      - min time: 0.091752 ms
      - max time: 0.274359 ms
      - average time: 0.154900 ms
     (0 connections failed!)
    Roundtrip timing results for 7 connections for 1000 round trips
      - min time: 24.967524 ms
      - max time: 166.282254 ms
      - average time: 95.243027 ms
    
    Simulating 7 clients.
    Establishing 7 connections... 
      successfully initiated 7 connection attempts!
    Connect timing results for 7 successful connections
      - min time: 0.102694 ms
      - max time: 0.232719 ms
      - average time: 0.137687 ms
     (0 connections failed!)
    Roundtrip timing results for 7 connections for 5000 round trips
      - min time: 123.335902 ms
      - max time: 800.731704 ms
      - average time: 466.645839 ms
    
    Simulating 7 clients.
    Establishing 7 connections... 
      successfully initiated 7 connection attempts!
    Connect timing results for 7 successful connections
      - min time: 0.115354 ms
      - max time: 0.251778 ms
      - average time: 0.153639 ms
     (0 connections failed!)
    Roundtrip timing results for 7 connections for 10000 round trips
      - min time: 243.019139 ms
      - max time: 1613.653152 ms
      - average time: 935.513325 ms
    
    Simulating 100 clients.
    Establishing 100 connections... 
      successfully initiated 100 connection attempts!
    Connect timing results for 87 successful connections
      - min time: 1.609835 ms
      - max time: 2308.660867 ms
      - average time: 851.971630 ms
     (13 connections failed!)
    Roundtrip timing results for 16 connections for 10000 round trips
      - min time: 458.816706 ms
      - max time: 2661.206231 ms
      - average time: 1795.466604 ms
    

##Exercise I.d.3
How long did it take for the connection attempts to time out?

> for this we were setting up the server and then set the simple client and multi client to connect to the server. The number of multi client was 100. Then we captured every connection after SYS_SENT and start to count using stopwatch. When the time out occurred, we measured the time and we were doing this for 5 times.

    Active Internet connections (including servers)
    Proto Recv-Q Send-Q  Local Address          Foreign Address        (state)    
    tcp4       0      0  localhost.57099        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57098        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57097        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57096        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57095        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57094        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57093        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57092        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57091        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57090        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57089        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57088        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57087        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57086        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57085        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57084        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57083        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57082        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57081        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57080        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57079        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57078        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57077        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57076        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57075        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57074        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57073        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57072        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57071        localhost.5703         SYN_SENT   
    tcp4       0      0  localhost.57070        localhost.5703         SYN_SENT
    ...                          
    

> then we started counting from this point until connection timed out. We carefully watched the terminal for any changing state.

    Yanuars-MacBook-Pro:Lab2 januaditya$ ./client-multi 0.0.0.0 5703 250 1000 > log_multi_blocking_250_1000.txt
      - conn 3 : async connect() error: Connection reset by peer
      - conn 4 : async connect() error: Connection reset by peer
      - conn 5 : async connect() error: Connection reset by peer
      - conn 6 : async connect() error: Connection reset by peer
      - conn 7 : async connect() error: Connection reset by peer
      - conn 10 : async connect() error: Connection reset by peer
      - conn 11 : async connect() error: Connection reset by peer
      - conn 12 : async connect() error: Connection reset by peer
      - conn 13 : async connect() error: Connection reset by peer
      - conn 15 : async connect() error: Connection reset by peer
      - conn 19 : async connect() error: Connection reset by peer
      - conn 20 : async connect() error: Connection reset by peer
      - conn 21 : async connect() error: Connection reset by peer
      - conn 24 : async connect() error: Connection reset by peer
      - conn 25 : async connect() error: Connection reset by peer
      - conn 26 : async connect() error: Connection reset by peer
      - conn 27 : async connect() error: Connection reset by peer
      - conn 28 : async connect() error: Connection reset by peer
      - conn 29 : async connect() error: Connection reset by peer
      - conn 30 : async connect() error: Connection reset by peer
      - conn 31 : async connect() error: Connection reset by peer
      - conn 32 : async connect() error: Connection reset by peer
      - conn 33 : async connect() error: Connection reset by peer
      - conn 34 : async connect() error: Connection reset by peer
      - conn 35 : async connect() error: Connection reset by peer
      - conn 36 : async connect() error: Connection reset by peer
      - conn 38 : async connect() error: Connection reset by peer
      - conn 41 : async connect() error: Connection reset by peer
      - conn 42 : async connect() error: Connection reset by peer
      - conn 43 : async connect() error: Connection reset by peer
      - conn 45 : async connect() error: Connection reset by peer
      - conn 47 : async connect() error: Connection reset by peer
      - conn 49 : async connect() error: Connection reset by peer
      - conn 50 : async connect() error: Connection reset by peer
      - conn 51 : async connect() error: Connection reset by peer
      - conn 52 : async connect() error: Connection reset by peer
      - conn 54 : async connect() error: Connection reset by peer
      - conn 55 : async connect() error: Connection reset by peer
      - conn 56 : async connect() error: Connection reset by peer
      - conn 57 : async connect() error: Connection reset by peer
      - conn 58 : async connect() error: Connection reset by peer
      - conn 59 : async connect() error: Connection reset by peer
      - conn 60 : async connect() error: Connection reset by peer
      - conn 61 : async connect() error: Connection reset by peer
      - conn 62 : async connect() error: Connection reset by peer
      - conn 63 : async connect() error: Connection reset by peer
      - conn 65 : async connect() error: Connection reset by peer
      - conn 66 : async connect() error: Connection reset by peer
      - conn 67 : async connect() error: Connection reset by peer
      - conn 68 : async connect() error: Connection reset by peer
      - conn 69 : async connect() error: Connection reset by peer
      - conn 70 : async connect() error: Connection reset by peer
      - conn 71 : async connect() error: Connection reset by peer
      - conn 72 : async connect() error: Connection reset by peer
      - conn 73 : async connect() error: Connection reset by peer
      - conn 75 : async connect() error: Connection reset by peer
      - conn 76 : async connect() error: Connection reset by peer
      - conn 77 : async connect() error: Connection reset by peer
      - conn 78 : async connect() error: Connection reset by peer
      - conn 80 : async connect() error: Connection reset by peer
      - conn 81 : async connect() error: Connection reset by peer
      - conn 82 : async connect() error: Connection reset by peer
      - conn 83 : async connect() error: Connection reset by peer
      - conn 85 : async connect() error: Connection reset by peer
      - conn 86 : async connect() error: Connection reset by peer
      - conn 87 : async connect() error: Connection reset by peer
      - conn 88 : async connect() error: Connection reset by peer
      - conn 89 : async connect() error: Connection reset by peer
      - conn 92 : async connect() error: Connection reset by peer
      - conn 93 : async connect() error: Connection reset by peer
      - conn 94 : async connect() error: Connection reset by peer
      - conn 95 : async connect() error: Connection reset by peer
      - conn 96 : async connect() error: Connection reset by peer
      - conn 102 : async connect() error: Connection reset by peer
      - conn 103 : async connect() error: Connection reset by peer
      - conn 107 : async connect() error: Connection reset by peer
      - conn 108 : async connect() error: Connection reset by peer
      - conn 201 : async connect() error: Operation timed out
      - conn 202 : async connect() error: Operation timed out
      - conn 203 : async connect() error: Operation timed out
      - ...
    

> We took 5 tries to find the ‘connection time-out’ time and the result:  
> &#8211; Take 1 = 26.7 seconds  
> &#8211; Take 2 = 26.5 seconds  
> &#8211; Take 3 = 26.8 seconds  
> &#8211; Take 4 = 26.5 seconds  
> &#8211; Take 5 = 27.0 seconds