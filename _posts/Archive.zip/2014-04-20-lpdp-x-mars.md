---
title: LPDP X Mars
excerpt: "I put in Soundcloud one of my best aransement yet. LOL. I'm kidding."
category: blog
layout: post
comments: true
tags: [LPDP, scholarship, guitar, soundcloud]
format: audio
---
* * *
<iframe width="100%" height="250" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/145596982&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>

> MARS LPDP X with Guitar Chords

<pre>Intro
   C Bb F               (Semangat juang kami....)

Verse
   F C F Bb F C Bb F    (Kami pemuda pemudi.....)
   C F C F-Bb-C         (Integritas dijunjung...)
   
Chorus
   Bb F C F Bb F C Bb F (PK Sepuluh semangat....)</pre>

>Intro:

Semangat juang kami takkan lekang

>Verse:

Kami pemuda pemudi Indonesia<br />
Angkatan sepuluh LPDP<br />
Bertakwa belajar dan bekerja<br />
Bekal membangun Negeri Tercinta<br />

  <span>Integritas dijunjung tinggi</span>

  <span>Profesional dalam mengabdi</span>

  <span>Sinergi untuk membangun negeri</span>

  <span>Itulah pedoman kami</span>


>Chorus:

PK sepuluh semangat bersatu<br />
Tunjukkan tanggung jawabmu<br />
LPDP wadahnya, LPDP jalannya<br />
Semangat PK kami takkan lekang<br />

>Verse:

Bermitra dalam membangun bangsa<br />
Kolaborasi bersama<br />
Kamilah pemimpin muda<br />
Generasi emas Indonesia<br />

  <span>Mandiri dalam beraksi</span>

  <span>Inovasi dalam kreasi</span>

  <span>Efektif efisien dan responsif</span>

  <span>Itulah angkatan kami</span>

>Chorus:

PK sepuluh semangat bersatu<br />
Tunjukkan janji bhaktimu<br />
Tak peduli rintangan dan hadapi tantangan<br />
Semangat juang kami takkan lekang<br />
Semangat juang kami takkan lekang<br />