---
title: Why '/' is Important in Sweden?
excerpt: "i'm not exaggerating!"
category: mumbling
layout: post
comments: true
tags: [quote, mumbling]
share: true
---

It means warm regards to all of you in email.

Cheers!