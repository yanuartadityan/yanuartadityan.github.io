---
title: Finally It's All About Time 2
excerpt: "After 9 months in Sweden"
category: mumbling
layout: post
comments: true
tags: [quote, mumbling]
share: true
---

Lastly, those 3 days was a happy moment for them, they were so proud about Indonesia, and I thought that was good for them. They need sympathy from all of us. They need to be acknowledged. Well, some of them are jackass for sure, but maybe because I was jealous when they got attention easily from the girls. LOL. Well, well done sir, you deserve that. Maybe&#8230;.just maybe.

Looking forward to meet those guys again anytime soon. Sukhoi!?

Cheers.