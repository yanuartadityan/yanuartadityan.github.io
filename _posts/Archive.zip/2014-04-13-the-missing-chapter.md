---
title: Long Game Part I - The Missing Chapter
excerpt: "Sometimes, genius point of view is often misleading. This is a great video that you won't regret to see."
category: blog
layout: post
comments: true
tags: [long game, vimeo, mumbling]
---
* * *
Do we have what it takes to do great things? After pretty much given up on everything, should you escape or get back on your feet?

Watch this and let creativity lead you onto the light. Learn from history greatest figures on how they achieved the success on the same way.

<iframe src="//player.vimeo.com/video/87448006?title=0&amp;byline=0&amp;portrait=0&amp;badge=0" width="500" height="281" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>

> &nbsp;
How? Wait for another great video from the same guy.