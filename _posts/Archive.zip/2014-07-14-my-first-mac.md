---
title: First MacBook Pro
excerpt: "I left my big time as an avid gamer. By buying my first Mac."
category: blog
layout: post
comments: true
tags: [apple, macbook, tech]
---
* * *
<div style="text-align:center">
<pre>
Be a yardstick of quality...
Some people aren't used to be inside of an 
environment where excellence is expected

--Steve Jobs--
</pre>
</div>

It's been a while you know since I owned a notebook. And it was in 2009 when I was picking ASUS UL30Vt. The laptop was damn good, dual GPU (Intel GMA and nVidia GT210M), 9-cells of battery which can power up the beef for ~8 good hours.

And now in 2014, I need a laptop which can serve me as whole myself. I mean, I am a prolific gamer and I am a prolific programmer too. And I feel like 2014 is the time for me to refresh my right-brain to be more useful and occupied by studying some design and artistry and sew them up into everything I&#8217;m gonna do for the next one or couple of years. Engineering with Art maybe, psyched!

Well, the answer is late 2013 15&#8243; Mac with Retina Display. It gained quite a lot of negative reviews though, commonly because it has hefty price tag which people think it can&#8217;t coupe with more gaming-oriented laptop .

I know it needs quite a lot of time to fully adapt into Mac OS X with its secrecies and stuffs, but I am happy to know that OS X isn&#8217;t that vintage as some Windows fans thought it might be.

Some of the good things are, e.g:  

1. Time Machine
2. KeyChain
3. Battery
4. 512GB PCIe SSD
5. Best TrackPad ever!

And lastly, Dota 2 runs great on this machine, doing ~60fps on 1680&#215;1050 (scaled down) with medium to high IQ. Not bad Apple, not bad.